<?php
class UrlController {
    private $urlModel;

    public function __construct() {
        $this->urlModel = new UrlModel();
    }

    public function create() {
        $url = $_POST['url'];
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            echo "Geçersiz URL!";
            return;
        }

        $existingUrl = $this->urlModel->getUrlByOriginalUrl($url);
        if ($existingUrl) {
            $shortCode = $existingUrl['short_code'];
        } else {
            $shortCode = $this->generateShortCode();
            $this->urlModel->createShortUrl($url, $shortCode);
        }

        echo "Kısa URL: http://localhost/deneme/$shortCode";
    }

    public function redirect($shortCode) {
        $urlData = $this->urlModel->getUrlByShortCode($shortCode);
        if ($urlData) {
            header("Location: " . $urlData['url']);
        } else {
            echo "URL bulunamadı!";
        }
    }

    private function generateShortCode() {
        return bin2hex(random_bytes(6));
    }
}
