<?php
class UrlModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function getUrlByShortCode($shortCode) {
        $stmt = $this->db->prepare("SELECT * FROM urls WHERE short_code = :short_code");
        $stmt->execute(['short_code' => $shortCode]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function createShortUrl($url, $shortCode) {
        $stmt = $this->db->prepare("INSERT INTO urls (url, short_code) VALUES (:url, :short_code)");
        $stmt->execute(['url' => $url, 'short_code' => $shortCode]);
    }

    public function getUrlByOriginalUrl($url) {
        $stmt = $this->db->prepare("SELECT * FROM urls WHERE url = :url");
        $stmt->execute(['url' => $url]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
