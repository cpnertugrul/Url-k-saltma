<?php
require 'core/Database.php';
require 'models/UrlModel.php';
require 'controllers/UrlController.php';

$path = trim($_SERVER['REQUEST_URI'], '/deneme');
$urlController = new UrlController();

if ($path == '' || $path == 'index.php') {
    require 'views/home.php';
} elseif ($path == 'create.php') {
    $urlController->create();
} else {
    $urlController->redirect($path);
}
