<!DOCTYPE html>
<html>
<head>
    <title>URL Kısaltma</title>
</head>
<body>
    <form action="create.php" method="post">
        <input type="text" name="url" placeholder="Uzun URL'i yapıştırın">
        <button type="submit">Kısalt</button>
    </form>
</body>
</html>
